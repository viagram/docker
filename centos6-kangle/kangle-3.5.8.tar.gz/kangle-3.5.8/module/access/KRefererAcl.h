#ifndef KREFERERACL_H
#define KREFERERACL_H
#include "KAcl.h"
#include "KVirtualHostContainer.h"
enum Referer_State
{
	Referer_NotNull,
	Referer_EqHost,
	Referer_Host
};
inline void referer_domain_iterator(void *arg,const char *domain,void *vh)
{
	std::stringstream *s = (std::stringstream *)arg;
	*s << domain << "|";
}
inline void count_domain_iterator(void *arg,const char *domain,void *vh)
{
	int *s = (int *)arg;
	(*s) += 1;
}
class KRefererAcl : public KAcl
{
public:
	KRefererAcl() {
		vhc = NULL;
	}
	~KRefererAcl() {
		if (vhc) {
			delete vhc;
		}
	}
	KAcl *newInstance() {
		return new KRefererAcl();
	}
	bool match(KHttpRequest *rq, KHttpObject *obj) {
		KHttpHeader *tmp = rq->parser.getHeaders();
		while (tmp) {
			if (is_attr(tmp,kgl_expand_string("Referer"))) {
				if (state==Referer_NotNull) {
					return true;
				}
				KUrl referer;
				if(!parse_url(tmp->val,&referer)){
					referer.destroy();
					return false;
				}
				bool matched=false;
				if (state==Referer_EqHost) {
					matched = strcasecmp(referer.host,rq->raw_url.host)==0;
				} else if (vhc) {
					matched = (vhc->find(referer.host)!=NULL);
				}
				referer.destroy();
				return matched;
			}
			tmp = tmp->next;
		}
		return false;
	}
	std::string getDisplay() {
		switch(state){
		case Referer_NotNull:
			return "NotNull";
		case Referer_EqHost:
			return "EqHost";
		case Referer_Host:
			int count = 0;
			std::stringstream s;
			s << "Host:";
			if (vhc) {
				vhc->iterator(count_domain_iterator,&count);
			}
			s << count;
			return s.str();
		}
		return "";
	}
	void editHtml(std::map<std::string,std::string> &attibute)
		throw (KHtmlSupportException)
	{
		if (vhc) {
			delete vhc;
			vhc = NULL;
		}
		if(strcasecmp(attibute["referer"].c_str(),"NotNull")==0){
			state = Referer_NotNull;		
		} else if(strcasecmp(attibute["referer"].c_str(),"EqHost")==0) {
			state = Referer_EqHost;
		} else {
			state = Referer_Host;
			vhc = new KVirtualHostContainer;
			char *buf = strdup(attibute["host"].c_str());
			char *hot = buf;
			for (;;) {
				char *p = strchr(hot,'|');
				if (p) {
					*p = '\0';
					p++;
				}
				vhc->bind(hot,this,kgl_bind_unique);
				if (p==NULL) {
					break;
				}
				hot = p;
			}
			free(buf);
		}
	}
	const char *getName() {
		return "referer";
	}
	std::string getHtml(KModel *model) {
		std::stringstream s;
		s << "<input type='radio' name='referer' value='NotNull' " << (state==Referer_NotNull?"checked":"") << ">NotNull";
		s << "<input type='radio' name='referer' value='EqHost' " << (state==Referer_EqHost?"checked":"") << ">EqHost";
		s << "<input type='radio' name='referer' value='Host' " << (state==Referer_Host?"checked":"") << ">Host";
		s << "<input type='text' name='host' value='";
		if (vhc) {
			vhc->iterator(referer_domain_iterator,&s);
		}
		s << "'>";
		return s.str();
	}
	void buildXML(std::stringstream &s) {
		s << " referer='" << getDisplay() << "' host='";
		if (vhc) {
			vhc->iterator(referer_domain_iterator,&s);
		}
		s << "'>";
	}
private:
	Referer_State state;
	KVirtualHostContainer *vhc;
};
#endif
