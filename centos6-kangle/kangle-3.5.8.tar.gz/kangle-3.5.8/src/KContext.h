#ifndef KCONTEXT_H
#define KCONTEXT_H
#include "KBuffer.h"
#include "global.h"
#include <assert.h>
#ifndef _WIN32
#include <sys/uio.h>
#endif
class KHttpTransfer;
class KHttpObject;
class KRequestQueue;
class KHttpRequest;
enum modified_type
{
	modified_if_modified,
	modified_if_range_date,
	modified_if_unmodified,
	modified_if_none_match,
	modified_if_range_etag
};
class KContext
{
public:
	inline KContext()
	{
		memset(this,0,sizeof(KContext));
	}
	~KContext()
	{
		assert(obj==NULL && old_obj==NULL);
		assert(st == NULL);
		if (if_none_match!=NULL) {
			if (if_none_match->data) {
				free(if_none_match->data);
			}
			free(if_none_match);
		}
	}
	void pushObj(KHttpObject *obj);
	void popObj();
	void set_if_none_match(const char *etag,int len)
	{
		if (if_none_match) {
			if (if_none_match->data) {
				free(if_none_match->data);
			}
		} else {
			if_none_match = (kgl_str_t *)malloc(sizeof(kgl_str_t));
		}
		if_none_match->data = (char *)malloc(len+1);
		if_none_match->len = len;
		memcpy(if_none_match->data,etag,len+1);		
	}
	KHttpObject *obj;
	KHttpObject *old_obj;
	
	bool haveStored;
	bool new_object;
	bool know_length;
	bool upstream_connection_keep_alive;
	bool connection_upgrade;
	bool always_on_model;
	bool stream_gziped;
	bool upstream_chunked;
	bool response_checked;
	bool no_body;
#ifndef NDEBUG
	bool upstream_expected_done;
	//���ڵ��ԣ���������socket
	SOCKET upstream_socket;
#endif
	//lastModified����
	modified_type mt;
	time_t lastModified;
	kgl_str_t *if_none_match;
	INT64 content_range_length;
	int keepAlive;
	//�첽���ļ�ʱ��Ҫ������
	INT64 left_read;

	KWStream *st;
	void clean();
	void store_obj(KHttpRequest *rq);
	void clean_obj(KHttpRequest *rq,bool store_flag = true);
};

#endif
