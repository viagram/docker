#ifndef KSPDYWRITEBUFFER_H
#define KSPDYWRITEBUFFER_H
#include <string.h>
#include <assert.h>
#ifndef _WIN32
#include <stdint.h>
#include <sys/uio.h>
#endif
#include "global.h"
#include "forwin32.h"
#include "KMutex.h"
#include "KSelector.h"
class kgl_http2_event
{
public:
	kgl_http2_event *next;
	void *arg;	
	bufferEvent buffer;	
	resultEvent result;	
	int len;	
};
class http2_buff
{
public:
	http2_buff()
	{
		memset(this,0,sizeof(*this));
	}
	~http2_buff();
	char *data;
	int used;
	int skip_data_free:1;
	int tcp_nodelay : 1;
	kgl_http2_event *e;
	http2_buff *next;
};
#define KGL_HEADER_FRAME_CHUNK_SIZE 4096
class KHttp2HeaderFrame
{
public:
	KHttp2HeaderFrame()
	{
		memset(this, 0, sizeof(KHttp2HeaderFrame));
	}
	~KHttp2HeaderFrame()
	{
		while (head) {
			last = head->next;
			free(head->data);
			delete head;
			head = last;
		}
	}
	http2_buff *create(uint32_t stream_id,bool no_body, size_t frame_size);
	void write_lower_string(const char *str, int len)
	{
		while (len) {
			int chunk_len = len;
			char *buf = alloc_buffer(chunk_len);
			len -= chunk_len;
			while (chunk_len) {
				*buf = tolower(*str);
				buf++;
				str++;
				chunk_len--;
			}
		}
	}
	void write_int(u_char type,uintptr_t prefix, uintptr_t value)
	{
		char buf[32];
		u_char *pos = (u_char *)buf;
		*pos = type;
		if (value < prefix) {
			*pos |= value;
			write(buf, 1);
			return;
		}

		*pos++ |= prefix;
		value -= prefix;

		while (value >= 128) {
			*pos++ = value % 128 + 128;
			value /= 128;
		}

		*pos++ = (u_char)value;
		write(buf, pos - (u_char *)buf);
		return;
	}
	void write(const u_char data)
	{
		write((char *)&data, 1);
	}
	void write(const char *str, int len)
	{
		while (len) {
			int chunk_len = len;
			char *buf = alloc_buffer(chunk_len);
			len -= chunk_len;
			memcpy(buf, str, chunk_len);			
			str += chunk_len;
		}
	}
private:
	char *alloc_buffer(int &len)
	{
		if (last == NULL || last->used == KGL_HEADER_FRAME_CHUNK_SIZE) {
			http2_buff *buf = new http2_buff;
			buf->data = (char *)malloc(KGL_HEADER_FRAME_CHUNK_SIZE);
			hot = buf->data;
			if (head == NULL) {
				head = buf;
			}
			if (last) {
				last->next = buf;
			}
			last = buf;
		}
		int left = KGL_HEADER_FRAME_CHUNK_SIZE - last->used;
		len = MIN(len, left);
		last->used += len;
		char *ret = hot;
		hot += len;
		return ret;
	}
	http2_buff *head;
	http2_buff *last;
	char *hot;
};
class KHttp2WriteBuffer
{
public:
	KHttp2WriteBuffer()
	{
		memset(this,0,sizeof(*this));
	}
	~KHttp2WriteBuffer()
	{
		KHttp2WriteBuffer::remove_buff(clean());
	}
	void getReadBuffer(KSocket *fd,LPWSABUF buffer,int &bufferCount)
	{
		if (!tcp_cork) {
			tcp_cork = 1;
			fd->setdelay();
		}
		assert(hot);
		int got = left;
		assert(header);
		http2_buff *tmp = header;
		buffer[0].iov_base = hot;
		int hot_left = header->used - (hot - header->data);
		hot_left = MIN(hot_left,got);
		buffer[0].iov_len = hot_left;
		got -= hot_left;
		int i;
		for (i=1;i<bufferCount;i++) {
			tmp = tmp->next;
			if (tmp==NULL || got<=0) {
				break;
			}
			buffer[i].iov_base = tmp->data;
			buffer[i].iov_len = MIN(got,tmp->used);
			got -= buffer[i].iov_len;
		}
		bufferCount = i;
	}
	http2_buff *readSuccess(KSocket *fd,int got)
	{
		http2_buff *remove_list = NULL;
		left -= got;
		while (got>0) {
			int hot_left = header->used - (hot - header->data);
			int this_len = MIN(got,hot_left);
			hot += this_len;
			got -= this_len;
			if (header->used == hot - header->data) {
				if (header->tcp_nodelay) {
					tcp_no_cork_at_empty = 1;
				}
				http2_buff *next = header->next;
				header->next = remove_list;
				remove_list = header;
				header = next;
				if (header==NULL) {
					reset();
					check_tcp_cork(fd);										
					return remove_list;
				}
				hot = header->data;
			}
		}
		if (left==0) {
			reset();
			check_tcp_cork(fd);						
		}
		return remove_list;
	}
	void push(http2_buff *buf)
	{
		while (buf) {
			add(buf,buf->used);
			buf = buf->next;
		}
	}
	int getBufferSize()
	{
		return left;
	}
	http2_buff *clean();
	/* return fin */
	static void remove_buff(http2_buff *remove_list)
	{
		 while (remove_list) {
			http2_buff *next = remove_list->next;
			delete remove_list;
			remove_list = next;
		}
		return;
	}
private:
	void reset()
	{
		assert(header == NULL);
		assert(left == 0);
		last = NULL;
		hot = NULL;
	}
	void check_tcp_cork(KSocket *fd)
	{
		if (tcp_no_cork_at_empty) {
			tcp_no_cork_at_empty = 0;
			if (!tcp_cork) {
				return;
			}
			tcp_cork = 0;
			fd->setnodelay();
		}
	}
	void add(http2_buff *buf,int len)
	{
		left += len;
		if (last==NULL) {
			assert(header==NULL);
			last = header = buf;
			hot = header->data;
		} else {
			last->next = buf;
			last = buf;
		}
	}
	http2_buff *last;
	http2_buff *header;
	char *hot;
	int left;
	uint16_t tcp_cork : 1;
	uint16_t tcp_no_cork_at_empty : 1;
};
#endif
