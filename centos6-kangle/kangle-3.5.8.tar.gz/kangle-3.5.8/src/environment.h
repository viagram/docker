#if	!defined(_ENVIRONMENT_H_INCLUDED_)
#define _ENVIRONMENT_H_INCLUDED_
#include	<errno.h>
#include 	<ctype.h>
#if	!defined(TRUE)
#define		TRUE		(1)
#endif
#if	!defined(FALSE)
#define		FALSE		(0)
#endif
#define		ERRNO			errno
#endif	
