<?php
error_reporting(0);
date_default_timezone_set("Asia/Shanghai");
global $ip,$addr,$addr2;

function Get_Web($url){
    $handle = fopen ($url, "rb"); 
    $contents = ""; 
    do{ 
        $data = fread($handle, 1024); 
         if(strlen($data) == 0) { 
            break; 
        } 
        $contents .= $data; 
    }while(true); 
    fclose ($handle); 
    return $contents;
}
    
function do_post_request($url, $data, $optional_headers = null) {
    $params = array(
        'http' => array(
            'method' => 'POST',
            'content' => $data
        )
    );
    if ($optional_headers !== null) {
        $params['http']['header'] = $optional_headers;
    }
    $ctx = stream_context_create($params);
    $fp = @fopen($url, 'rb', false, $ctx);
    if (!$fp) {
        throw new Exception("Problem with $url, $php_errormsg");
    }
    $response = @stream_get_contents($fp);
    if ($response === false) {
        throw new Exception("Problem reading data from $url, $php_errormsg");
    }
    return $response;
}
/**************************************************************
 *
 *    使用特定function对数组中所有元素做处理
 *    @param    string    &$array        要处理的字符串
 *    @param    string    $function    要执行的函数
 *    @return boolean    $apply_to_keys_also        是否也应用到key上
 *    @access public
 *
 *************************************************************/
function arrayRecursive(&$array, $function, $apply_to_keys_also = false) {
    static $recursive_counter = 0;
    if (++$recursive_counter > 1000) {
        die('possible deep recursion attack');
    }
    foreach ($array as $key => $value) {
        if (is_array($value)) {
            arrayRecursive($array[$key], $function, $apply_to_keys_also);
        } else {
            $array[$key] = $function($value);
        }
        if ($apply_to_keys_also && is_string($key)) {
            $new_key = $function($key);
            if ($new_key != $key) {
                $array[$new_key] = $array[$key];
                unset($array[$key]);
            }
        }
    }
    $recursive_counter--;
}
/**************************************************************
 *
 *    将数组转换为JSON字符串（兼容中文）
 *    @param    array    $array        要转换的数组
 *    @return string        转换得到的json字符串
 *    @access public
 *
 *************************************************************/
function JSON($array) {
    arrayRecursive($array, 'urlencode', true);
    $json = json_encode($array);
    return urldecode($json);
}
function GetIp() {
    if ($_SERVER["HTTP_X_FORWARDED_FOR"]) {
        $ip = $_SERVER["HTTP_X_FORWARDED_FOR"];
    } elseif ($_SERVER["HTTP_CLIENT_IP"]) {
        $ip = $_SERVER["HTTP_CLIENT_IP"];
    } elseif ($_SERVER["REMOTE_ADDR"]) {
        $ip = $_SERVER["REMOTE_ADDR"];
    } elseif (getenv("HTTP_X_FORWARDED_FOR")) {
        $ip = getenv("HTTP_X_FORWARDED_FOR");
    } elseif (getenv("HTTP_CLIENT_IP")) {
        $ip = getenv("HTTP_CLIENT_IP");
    } elseif (getenv("REMOTE_ADDR")) {
        $ip = getenv("REMOTE_ADDR");
    } else {
        $ip = "Unknown";
    }
    return $ip;
}
if ($_REQUEST['format'] == 'ip') {
    die(GetIp());
}
$phpself = end(explode('/', $_SERVER['PHP_SELF']));
$domain = $_SERVER['SERVER_NAME'];
$head = <<<html
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>{$domain}- IP 地址查询 | 地理位置 | 手机归属地 | 手机号码查询</title>
<meta name="robots" content="all" />
<meta name="Keywords" content="ip,ip查询,手机ip,手机号,手机号码,手机号码归属地,IP,IP查询,本机IP,外网IP,IP地址查询,地理位置查询,归属地">
<meta name="Description" content="专业本机 IP 地址查询,手机 IP 地址,地理位置查询,IP 数据库,手机号归属地查询,精确 IP 数据库">
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="http://{$domain}/mobile.png">
<link rel="apple-touch-icon-precomposed" sizes="57x57" href="http://{$domain}/mobile.png">
<link href='http://{$domain}/bootstrap.min.css' rel='stylesheet' type='text/css'>
<meta name="viewport" content="width=device-width, minimum-scale=0.5">
<meta name="format-detection" content="telephone=no">
<link href='http://{$domain}/main.css' rel='stylesheet' type='text/css'>
<div id='wx_logo' style='margin:0 auto;display:none;'>
<img src='/mobile.png' />
</div>
</head>
<div class="header">
    <a href="http://{$domain}"  target="_blank"><img src="http://{$domain}/logo.png"></a><br>
</div>
<div class="mainbar">
    <ul class="nav nav-pills center-pills">
        <li class="active"><a href="/">IP地址归属地查询</a></li>
        <li><a href="/sj.php">手机号码归属地查询</a></li>
    </ul>
</div>
<div class="searchform">
<body onload="document.getElementById('addr').focus();">
    <form name="fs" action="/{$phpself}" method="GET" class="form-search">
        <input id="addr" name="ip" type="text" placeholder="请输入要查询的域名或 IP 地址" class="span3">
        <input id="s" type="submit" class="btn btn-primary" value="查询">
    </form>
</div>
html;
$footer = <<<footer

<div class="footer">
    <hr>
    <script>
        var _hmt = _hmt || [];
        (function() {
            var hm = document.createElement("script");
            hm.src = "//hm.baidu.com/hm.js?2e4c6cfb933f14d154d3bf94e5461856";
           var s = document.getElementsByTagName("script")[0]; 
           s.parentNode.insertBefore(hm, s);
        })();
    </script>
    <p><a href="http://{$domain}"  target="_blank">{$domain}</a> &copy;2014-2016 &nbsp; 偉哥無限</p>
</div>
<body>
</body>
</html>
footer;
if (empty($_REQUEST['ip'])) $ip = GetIp();
else $ip = trim($_REQUEST['ip']);
include 'idna_convert.class.php';
$IDN = new idna_convert();
if (preg_match("/^([0-9]{1,3}.){3}[0-9]{1,3}$/", $ip) === 0){
    $ym = explode("/",str_replace(array("https://","http://",'。'),array("","",'.'),$ip));
    $ym2 = $ym[0];
    if (preg_match("/^([0-9]{1,3}.){3}[0-9]{1,3}$/", $ym2) === 0){
        $zip = gethostbyname($IDN->encode($ym2));
        //$zip = trim(Get_Web("http://ip.zuzb.com/GetDnslookup.php?Domain=".$IDN->encode($ym2)));
        if ( ($zip == $IDN->encode($ym2)) || preg_match("/^([0-9]{1,3}.){3}[0-9]{1,3}$/", $zip) == 0) {
            echo $head;
            $IPerr = <<< IPerr

<div id="result">
    <div class="well">
        <center>
            <p>你输的入: <code>{$ym2}</code>无法转换为有效IP地址。</p>
        </center>
    </div>
</div>
IPerr;
            die($IPerr.$footer);
        }
        else $ip =$zip;
    }
    else $ip = $ym2;
}
include 'ipCity.Class.php';
$city = new ipCity();
$addr = $city->getCity($ip);
include 'freeapi.ipip.net.class.php';
$city2 = new FreeAPI();
$addr2 = $city2->findaddr($ip); 
require dirname(__FILE__) . '/Ip2Region.class.php';
$dbFile = dirname(__FILE__) . '/ip2region.db';
$fs     = 'memory';
if ( isset($fs) ) {
    switch ( strtolower($fs) ) {
    case 'binary':
        $method    = 'binarySearch';
        break;
    case 'memory':
        $method    = 'memorySearch';
        break;
    }
}
$ip2regionObj = new Ip2Region($dbFile);
if ( ip2long($ip) == NULL ) {
    die("Error: invalid ip address\n");
}
$data   = $ip2regionObj->{$method}($ip);
$addrArry   = explode('|', $data['region']);
if ($addrArry[0] == "0") {
    $addr3 = "";
}else{
    if ($addrArry[0] == "中国") {
        $addr3 = "";
    } else {
        $addr3 = $addrArry[0];
    }
}
if ($addrArry[1] == "0") {
    $addr3 = $addr3;
}else{
    if ($addrArry[0] == "中国") {
        $addr3 = "";
    } else {
        $addr3 = $addr3 . " " . $addrArry[1] . "地区";
    }
}
if ($addrArry[2] == "0") {
    $addr3 = $addr3;
}else{
    $addr3 = $addr3 . " " . $addrArry[2];
}
if ($addrArry[3] == "0"){
    $addr3 = $addr3;
}else{
    $addr3 = $addr3 . " " . $addrArry[3];
}
if ($addrArry[4] == "0"){
    $addr3 = $addr3;
}else{
    $addr3 = $addr3 . " " . $addrArry[4];
}

if ($_REQUEST['format'] == 'json') {
    $array = array(
        'IP' => $ip,
        'Address1' => $addr,
        'Address2' => $addr2,
        'Address3' => $addr3,
    );
    die(JSON($array));
}
if ($_REQUEST['format'] == 'addr') {
    die($ip."||".$addr."||".$addr2."||".$addr3);
}
echo $head;
include 'forIP.Class.php';
$ForIP = new ForIP();
$EchoIP = $ForIP->EchoIP($ip); 
if (empty($_REQUEST['ip'])) {
    $IP = <<<IP

<div id="result">
    <div class="well">
        <center>
            <p>本机的IP：<code>{$ip}</code></p><hr>
            <p>参考数据一: <code2>{$addr}</code2></p><hr>
            <p>参考数据二: <code2>{$addr2}</code2></p><hr>
            <p>参考数据三: <code2>{$addr3}</code2></p>
    {$EchoIP}
        </center>
    </div>
</div>
IP;
//<p><a href="http://{$domain}/?ip={$ip}"  target="_blank">{$ip}</a></p>
echo $IP;
} else {
    if(($ym2 !== $ip) && (!empty($ym2))) $ips = $ym2." >>> ".$ip;
    else $ips = $ip;
    $IP = <<<IP

<div id="result">
    <div class="well">
        <center>
            <p>查询的IP：<code>{$ips}</code></p><hr>
            <p>参考数据一: <code2>{$addr}</code2></p><hr>
            <p>参考数据二: <code2>{$addr2}</code2></p><hr>
            <p>参考数据三: <code2>{$addr3}</code2></p>
        </center>
    </div>
    <center>
    {$EchoIP}
    </center>
</div>
IP;
echo $IP;
}
print $footer;
//die("IP:\"".$ip."\";Address:\"".$addr."\"");
//$ip."<br>".file_get_contents('php://input');
