<?php
//error_reporting(0);
global $p,$c,$EchoP;
function Read_Web($url){
    $handle = fopen($url, "rb"); 
    $contents = ""; 
    do{ 
        $data = fread($handle, 1024); 
        if(strlen($data) == 0) { 
            break; 
        } 
        $contents .= $data; 
    }while(true); 
    fclose ($handle); 
    return $contents;
}
$phpself = end(explode('/', $_SERVER['PHP_SELF']));
$domain = $_SERVER['SERVER_NAME'];
$p = trim($_REQUEST['p']);
$c = trim($_REQUEST['c']);
if (preg_match("/13[45789]{1}\d{8}$/",$p)){
    if (preg_match("/134[9]{1}\d{7}$/",$p)){
        $chk=4;
    }else{
        $chk=1;
    }
}elseif (preg_match("/14[7]{1}\d{8}$/",$p)){
    $chk=1;
}elseif (preg_match("/15[012789]{1}\d{8}$/",$p)){
    $chk=1;
}elseif (preg_match("/17[8]{1}\d{8}$/",$p)){
    $chk=1;
}elseif (preg_match("/18[23478]{1}\d{8}$/",$p)){
    $chk=1;
}elseif (preg_match("/13[012]{1}\d{8}$/",$p)){
    $chk=2;
}elseif (preg_match("/14[5]{1}\d{8}$/",$p)){
    $chk=2;
}elseif (preg_match("/15[56]{1}\d{8}$/",$p)){
    $chk=2;
}elseif (preg_match("/17[6]{1}\d{8}$/",$p)){
    $chk=2;
}elseif (preg_match("/18[56]{1}\d{8}$/",$p)){
    $chk=2;
}elseif (preg_match("/13[3]{1}\d{8}$/",$p)){
    $chk=3;
}elseif (preg_match("/15[3]{1}\d{8}$/",$p)){
    $chk=3;
}elseif (preg_match("/17[7]{1}\d{8}$/",$p)){
    $chk=3;
}elseif (preg_match("/18[019]{1}\d{8}$/",$p)){
    $chk=3;
}else{
    $chk=0;
}
include 'ForPhone.Class.php';
$ForP = new ForPhone();
if($chk !== 0) $EchoP = $ForP->EchoPhone($p);
else $EchoP = $ForP->EchoPhone(NULL);
$head = <<<html
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>{$domain}- 手机号码查询 | IP 地址查询 | 地理位置 | 手机归属地</title>
<meta name="robots" content="all" />
<meta name="Keywords" content="ip,ip查询,手机ip,手机号,手机号码,手机号码归属地,IP,IP查询,本机IP,外网IP,IP地址查询,地理位置查询,归属地">
<meta name="Description" content="专业本机 IP 地址查询,手机 IP 地址,地理位置查询,IP 数据库,手机号归属地查询,精确 IP 数据库">
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="http://{$domain}/mobile.png">
<link rel="apple-touch-icon-precomposed" sizes="57x57" href="http://{$domain}/mobile.png">
<link href='http://{$domain}/bootstrap.min.css' rel='stylesheet' type='text/css'>
<meta name="viewport" content="width=device-width, minimum-scale=0.5">
<meta name="format-detection" content="telephone=no">
<link href='http://{$domain}/main.css' rel='stylesheet' type='text/css'>
<div id='wx_logo' style='margin:0 auto;display:none;'>
<img src='/mobile.png' />
</div>
</head>
<div class="header">
    <a href="http://{$domain}"  target="_blank"><img src="http://{$domain}/logo.png"></a><br>
</div>
<div class="mainbar">
    <ul class="nav nav-pills center-pills">
        <li><a href="/">IP地址归属地查询</a></li>
        <li class="active"><a href="/{$phpself}">手机号码归属地查询</a></li>
    </ul>
</div>
<div class="searchform">
<body onload="document.getElementById('hm').focus();">
    <form name="fs" action="/{$phpself}" method="GET" class="form-search">
        <input type="hidden" name="c" value="1">
        <input id="hm" name="p" type="text" placeholder="请输入要查询的手机号码" class="span3">
        <input id="s" type="submit" class="btn btn-primary" value="查询">
    </form>
</div>
html;
$foot = <<<footer

<center>
  {$EchoP}
</center>
<div class="footer">
    <hr>
    <script>
        var _hmt = _hmt || [];
        (function() {
            var hm = document.createElement("script");
            hm.src = "//hm.baidu.com/hm.js?2e4c6cfb933f14d154d3bf94e5461856";
           var s = document.getElementsByTagName("script")[0]; 
           s.parentNode.insertBefore(hm, s);
        })();
    </script>
    <p><a href="http://{$domain}"  target="_blank">{$domain}</a> &copy;2014-2016 &nbsp; 偉哥無限</p>
    <p><a href="http://www.miitbeian.gov.cn/"  target="_blank">浙ICP备16009916号</a></p>
</div>
<body>
</body>
</html>
footer;
$OnCreat = <<< OnCreat

<div id="result">
    <div class="well">
        <center>
            <p>请输入要查询的手机号码</p>
        </center>
    </div>
</div>
OnCreat;
$Empty = <<< Empty

<div id="result">
    <div class="well">
        <center>
            <p><code>手机号码不能为空!</code></p>
        </center>
    </div>
</div>
Empty;
$Error = <<< Error

<div id="result">
    <div class="well">
        <center>
            <p>你的输入: <code>{$p}</code> 无效, 请核对!</p>
        </center>
    </div>
</div>
Error;
if ((empty($p)) && (!empty($c))){
    echo $head;
    echo $Empty;
    die($foot);
}elseif ((empty($p)) && (empty($c))){
    echo $head;
    echo $OnCreat;
    die($foot);
}
if ($chk === 1){
    $bs = '移动';
}elseif ($chk === 2){
    $bs = '联通';
}elseif ($chk === 3){
    $bs = '电信';
}elseif ($chk === 4){
    $bs = '卫通';
}
if ($chk !== 0){
    $gs = Read_Web('http://app.m.zj.chinamobile.com/zjweb/AttributionSearch.do?phonenumber='.$p);
    $s=json_decode($gs,true);
    if (empty($s['msg'])){
        $addr = $s['provincename'].' '.$s['reginname'].' '.$bs.' '.$s['countryname'];
    }else{
        $addr = $s['msg'];
    }
    $IsOK = <<<IsOK
<div id="result">
    <div class="well">
        <center>
            <p>查询的号码：<code>{$p}</code></p><hr>
            <p>参考归属地: <code2>{$addr}</code2></p><hr>
        </center>
    </div>
</div>
IsOK;
    echo $head;
    echo $IsOK;
    die($foot);
}else{
    echo $head;
    echo $Error;
    die($foot);
}

