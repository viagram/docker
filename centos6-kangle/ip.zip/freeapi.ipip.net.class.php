<?php
class FreeAPI
{
    private static $ip       = NULL;
    private static $addr     = NULL;
    private static $addrarry = NULL;
	
	public static function findaddr($ip){
		//$addrarry = @file_get_contents('http://freeapi.ipip.net/'.$ip);
		//if(empty($addrarry)) $addrarry = @file_get_contents('http://vpn.zuzb.com/?'.$ip);
		$addrarry = @self::Read_Web('http://freeapi.ipip.net/'.$ip);
		if(!empty($addrarry)){
			$addrarry = explode(',',str_replace(array('[',']','"','\\'),'',trim($addrarry)));
			$addr = trim(str_replace(array($addrarry[0].$addrarry[0],$addrarry[1].$addrarry[1]),array($addrarry[0],$addrarry[1]),$addrarry[0].$addrarry[1].$addrarry[2].$addrarry[3]." ".$addrarry[4]));
		}
		if ((!empty($addr)) && (strpos($addr, "example") === false)){
			if($addr == '局域网') return '内部局域网';
		    else return $addr;
		}else{
			include 'ipip.net.class.php';
			$city = new IP();
			$addrarray = $city->find($ip); 
			$addr = trim(str_replace(array($addrarray[0]." ".$addrarray[0],$addrarray[1]." ".$addrarray[1]),array($addrarray[0],$addrarray[1]),$addrarray[0]." ".$addrarray[1]." ".$addrarray[2]." ".$addrarray[3]));
			if($addr == '局域网') $addr = '内部局域网';
			return $addr;
		}
	}
	private static function Read_Web($url){
		$handle = fopen ($url, "rb"); 
		$contents = ""; 
		do{ 
		    $data = fread($handle, 1024); 
		    if(strlen($data) == 0) { 
		        break; 
		    } 
		    $contents .= $data; 
		}while(true); 
		fclose ($handle); 
		return $contents;
	}
}
?>