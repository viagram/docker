<?php
class ForIP
{
    private static $ip    = NULL;
    private static $S     = 59;
    private static $F     = "Echo_IP_Array.txt";
    
    public static function EchoIP($ip){
        $ip = trim($ip);
        $Domain = $_SERVER['SERVER_NAME'];
        $ra = @self::R_IP(self::$F);
        $a = explode(',',str_replace($ip.',','', $ra));
        $a = self::dx($a);
        $b = count($a)-1;
        if(strpos($ra, $ip) === false){
            if($b>180){
                $i = 60;
                self::W_IP($ip, 'w');
                  while($i<=$b-1){
                       self::W_IP($a[$i]);
                    $i++;
                }
            }else{
                self::W_IP($ip);
            }
        }
        if($b>=self::$S) $ii = $b - self::$S;
        else $ii = 0;
        $a = self::dx($a);
        $count = 2;
        while($ii<=$b - 1){
            $result .= "\n".'                <p>历史IP地址，IP归属地查询'.$count.': <a href="http://'.$Domain.'/?ip='.$a[$ii].'"  target="_blank">'.$a[$ii].'</a></p>';
            //if ($ii%3==0) $result .= '</p>         <p>';
            $count++;
            $ii++;
        }
        $result = <<<ForIP
        <div style="display:none;">
                <p>历史IP地址，IP归属地查询1: <a href="http://{$Domain}/?ip={$ip}"  target="_blank">{$ip}</a></p>{$result}
            </div>
ForIP;
        return $result;
    }
    private static function W_IP($T, $W=''){
        if(!file_exists(self::$F)){
            touch(self::$F);
            $W = 'w';
        }
        if(is_writable(self::$F)){
            if($W === 'w'){
                $fl=fopen(self::$F,"w");
                fwrite($fl,$T);
            }else{
                $fl=fopen(self::$F,"a");
                fwrite($fl,','.$T);
            }
            fclose($fl);
        }
    }
    private static function R_IP($F){
        if(file_exists(self::$F)){
            $handle = fopen (self::$F, "rb"); 
            $contents = ""; 
            do{ 
                $data = fread($handle, 1024); 
                if(strlen($data) == 0) break; 
                $contents .= $data; 
            }while(true); 
            fclose($handle); 
            $a = explode(',',str_replace(',,',',', $contents));
            $a = array_unique($a);
            $a = implode(",", $a);
            return $a;
        }
    }
    private static function dx($a){
        //$a = array($a);
        for($i=0;$i<count($a);$i++){
            $b[count($a)-$i-1]=$a[$i];
        }
        //for($j=0;$j<count($a);$j++){
        //    $dd .= $b[$j].',';
        //}
        return $b;
    }

}
?>