<?php
class ForPhone
{
    private static $p = NULL;
    private static $S = 59;
    private static $F = "Echo_Phone_Array.txt";
    
    public static function EchoPhone($p){
        $p = trim($p);
        $Domain = $_SERVER['SERVER_NAME'];
        $ra = @self::Reader(self::$F);
        if(!empty($p)){
            $a = explode(',',str_replace($p.',','', $ra));
            $count = 2;
        }else{
            //self::$S = 12;
            $a = explode(',',$ra);
            $count = 1;
        }
        $a = self::dx($a);
        $b = count($a);
        if((strpos($ra, $p) === false) && (!empty($p))){
            if($b>180){
                $i = 60;
                self::Writer($p, 'w');
                  while($i<=$b-1){
                       self::Writer($a[$i]);
                    $i++;
                }
            }else{
                self::Writer($p);
            }
        }
        if($b>self::$S) $ii = $b - self::$S;
        else $ii = 0;
        $a = self::dx($a);
        while($ii<=$b - 1){
            $result .= "\n".'    <p>手机号码查询，手机归属地查询'.$count.': <a href="http://'.$Domain.'/sj.php?c=1&p='.$a[$ii].'"  target="_blank">'.$a[$ii].'</a></p>';
            //if ($ii%3==0) $result .= '</p>         <p>';
            $count++;
            $ii++;
        }
        if(!empty($p)){
            $result = <<<ForIP
<div style="display:none;">
    <p>手机号码查询，手机归属地查询1: <a href="http://{$Domain}/sj.php?c=1&p={$p}"  target="_blank">{$p}</a></p>{$result}
</div>
ForIP;
        }else{
            $result = <<<ForIP
<div style="display:none;">{$result}
</div>
ForIP;
        }
        return $result;
    }
    private static function Writer($T, $W=''){
        if(!file_exists(self::$F)){
            touch(self::$F);
            $W = 'w';
        }
        if(is_writable(self::$F)){
            if($W === 'w'){
                $fl=fopen(self::$F,"w");
                fwrite($fl,$T);
            }else{
                $fl=fopen(self::$F,"a");
                fwrite($fl,','.$T);
            }
            fclose($fl);
        }
    }
    private static function Reader($F){
        if(file_exists(self::$F)){
            $handle = fopen (self::$F, "rb"); 
            $contents = ""; 
            do{ 
                $data = fread($handle, 1024); 
                if(strlen($data) == 0) break; 
                $contents .= $data; 
            }while(true); 
            fclose($handle); 
            return $contents;
        }
    }
    private static function dx($a){
        //$a = array($a);
        for($i=0;$i<count($a);$i++){
            $b[count($a)-$i-1]=$a[$i];
        }
        //for($j=0;$j<count($a);$j++){
        //    $dd .= $b[$j].',';
        //}
        return $b;
    }

}
?>